
# Spark

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** | your email | 
**data** | **String** | target data name | 
**target** | **String** | callback target (email or slack) |  [optional]
**user** | **String** | callback address |  [optional]
**APP** | **String** | target app name | 
**word** | **String** | Option to count the number of specific words (case sensitive) |  [optional]




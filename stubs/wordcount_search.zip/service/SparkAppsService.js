'use strict';


/**
 * Apps that count the number of specific characters
 * Apps that count the number of specific characters
 *
 * body JSON Data for running the app
 * no response value expected for this operation
 **/
exports.wordcount_search = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


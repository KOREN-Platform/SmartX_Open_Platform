'use strict';


/**
 * app meta datas
 * 
 *
 * body Spark apps desemailcription
 * no response value expected for this operation
 **/
exports.wordcount_search = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


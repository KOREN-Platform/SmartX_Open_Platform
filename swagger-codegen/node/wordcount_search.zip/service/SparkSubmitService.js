'use strict';


/**
 * Add a new pet to the store
 * 
 *
 * body Spark spark object that needs to be needed to the run
 * no response value expected for this operation
 **/
exports.sparkSubmit = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


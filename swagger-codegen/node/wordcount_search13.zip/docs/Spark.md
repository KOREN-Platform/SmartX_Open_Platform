
# Spark

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** |  | 
**data** | **String** |  | 
**target** | **String** |  | 
**user** | **String** |  | 
**APP** | **String** |  | 




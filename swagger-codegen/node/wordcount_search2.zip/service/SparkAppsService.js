'use strict';


/**
 * app meta datas
 * 
 *
 * body Spark apps description
 * no response value expected for this operation
 **/
exports.wordcount_search2 = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


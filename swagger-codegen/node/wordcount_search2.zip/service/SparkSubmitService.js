'use strict';


/**
 * apps description
 * 
 *
 * body Spark apps description
 * no response value expected for this operation
 **/
exports.wordcount_search2.py = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


'use strict';


/**
 * You can running spark application by this API
 * 
 *
 * body Spark spark object that needs to be needed to the run
 * no response value expected for this operation
 **/
exports.sparkSubmit = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

